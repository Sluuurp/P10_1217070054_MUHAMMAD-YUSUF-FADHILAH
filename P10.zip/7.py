import cv2
from matplotlib import pyplot as plt

sawit = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/pohonsaweet.jpeg")
sawit = cv2.cvtColor(sawit, cv2.COLOR_BGR2RGB)

Perkebunan_Sawit = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/saweet.jpeg")
Perkebunan_Sawit = cv2.cvtColor(Perkebunan_Sawit, cv2.COLOR_BGR2RGB)

plt.figure(figsize=(12, 6))

plt.subplot(121)
plt.imshow(sawit)
plt.title('Pohon Sawit')
plt.xticks([]), plt.yticks([])
plt.subplot(122)
plt.imshow(Perkebunan_Sawit)
plt.title('Perkebunan Sawit')
plt.xticks([])
plt.yticks([])

plt.tight_layout()
plt.show()