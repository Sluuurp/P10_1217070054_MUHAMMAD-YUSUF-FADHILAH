import cv2
import numpy as np

img_rgb = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/saweet.jpeg")
img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
template = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/pohonsaweet.jpeg")

w = template.shape[::-1]
h = template.shape[::-1]

res = cv2.matchTemplate(img_gray, template, cv2.TM_CCOEFF_NORMED)

threshold = 0.15
loc = np.where(res >= threshold)

lspoint = []
lspoint2 = []
count = 0  

for pt in zip(*loc[::-1]):
    if pt[0] not in lspoint and pt[1] not in lspoint2:
        cv2.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0, 255, 255), 2)
        for i in range(pt[0] - 9, pt[0] + 9):
            lspoint.append(i)
        for k in range(pt[1] - 9, pt[1] + 9):
            lspoint2.append(k)
        count += 1
    else:
        continue

print("Jumlah objek ditemukan:", count)
cv2.imshow(img_rgb)