import cv2
from matplotlib import pyplot as plt

einstein = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/bangmelet.jpg")
einstein = cv2.cvtColor(einstein,cv2.COLOR_BGR2RGB)

solvay = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/solvaycon.jpg")
solvay = cv2.cvtColor(solvay,cv2.COLOR_BGR2RGB)

plt.subplot(121)
plt.imshow(einstein)
plt.title('Einstein')
plt.axis('off')
plt.subplot(122)
plt.imshow(solvay)
plt.title('Solvay Conference 1927')
plt.axis('off')
plt.show()