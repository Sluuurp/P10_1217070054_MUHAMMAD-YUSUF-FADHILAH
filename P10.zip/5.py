import numpy as np
import cv2
from matplotlib import pyplot as plt

img1 = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/4/gura.jpeg")
img2 = cv2.imread("C:/Users/muham/OneDrive/Dokumen/PEMROGRAMAN/Visual Studio/Python/opencv/7/guranyungsep.jpeg")

gray1= cv2.cvtColor(img1,cv2.COLOR_BGR2GRAY)
gray2= cv2.cvtColor(img2,cv2.COLOR_BGR2GRAY)

sift = cv2.xfeatures2d.SIFT_create()
kp1, des1 = sift.detectAndCompute(gray1,None)
kp2, des2 = sift.detectAndCompute(gray2,None)

bf = cv2.BFMatcher()
matches = bf.knnMatch(des1,des2, k=2)

good = []   
for m,n in matches:
  if m.distance < 0.5*n.distance:
    good.append([m])

img3 = cv2.drawMatchesKnn(img1,kp1,img2,kp2,good,None,flags=2)
plt.imshow(cv2.cvtColor(img3, cv2.COLOR_BGR2RGB))
plt.show()